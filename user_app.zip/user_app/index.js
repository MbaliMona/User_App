const express = require("express");
const multer = require("multer");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const app = express();
const storage = multer.memoryStorage();
const upload = multer({ storage });


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/public"));

mongoose.connect("mongodb://localhost/mydb", { useNewUrlParser: true });

module.exports = mongoose.model('Customer',customerSchema)


app.post("/submit-form", upload.single("myFile"), (req, res) => {
    const customer = new Customer({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      dob: req.body.dob,
      file: { data: req.file.buffer, contentType: req.file.mimetype }
    });
  
    customer.save((err, user) => {
      if (err) return res.send(err);
      res.redirect("/graph");
    });
  });


