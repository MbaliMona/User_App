const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    dob: Date,
    file: { data: Buffer, contentType: String }
  });
  
  const User = mongoose.model("User", UserSchema);